#!/usr/bin/python3

import dbus
import datetime

from advertisement import Advertisement
from service import Application, Service, Characteristic, Descriptor

GATT_CHRC_IFACE = "org.bluez.GattCharacteristic1"
NOTIFY_TIMEOUT = 5000

class ProxusAdvertisement(Advertisement):
    def __init__(self, index):
        Advertisement.__init__(self, index, "peripheral")
        self.add_local_name("Proxus")
        self.include_tx_power = True

class ProxusService(Service):
    PROXUS_SVC_UUID = "00000001-810e-4a5b-8d75-3e5b444bc3cf"

    def __init__(self, index):
        Service.__init__(self, index, self.PROXUS_SVC_UUID, True)
        self.add_characteristic(PnotificationCharacteristic(self))
        self.add_characteristic(PcontrolCharacteristic(self))

class PnotificationCharacteristic(Characteristic):
    PNOTIFICATION_CHARACTERISTIC_UUID = "00000002-810e-4a5b-8d75-3e5b444bc3cf"

    def __init__(self, service):
        Characteristic.__init__(
                self, self.PNOTIFICATION_CHARACTERISTIC_UUID,
                ["read"], service)

    def ReadValue(self, options):
        value = []

        timestamp = datetime.datetime.now()
        ipaddr = timestamp.strftime("Intrusion Detected at %A %d %B %Y %I:%M:%S%p")
        for c in ipaddr:
            value.append(dbus.Byte(c.encode()))

        return value


class PcontrolCharacteristic(Characteristic):
    PCONTROL_CHARACTERISTIC_UUID = "00000003-810e-4a5b-8d75-3e5b444bc3cf"

    def __init__(self, service):
        Characteristic.__init__(
                self, self.PCONTROL_CHARACTERISTIC_UUID,
                ["write"], service)

    def WriteValue(self, value, options):
        valw = ''.join(str(e) for e in value)
        print(valw)



app = Application()
app.add_service(ProxusService(0))
app.register()

adv = ProxusAdvertisement(0)
adv.register()

try:
    app.run()
except KeyboardInterrupt:
    app.quit()
    print("\nGATT application terminated")